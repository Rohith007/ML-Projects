# Datasets

The datasets are hosted in a Kaggle competition. Please download data from the link provided.

This following link contains both **train(train.json.7z)** and **test(test.json.7z)** data. **https://www.kaggle.com/c/statoil-iceberg-classifier-challenge/data**
